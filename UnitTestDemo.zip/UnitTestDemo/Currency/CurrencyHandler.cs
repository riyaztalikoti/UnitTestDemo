﻿using Newtonsoft.Json;
using System;
using System.Net.Http;

namespace UnitTestDemo.Currency
{
    // Mock
    public class CurrencyHandler : ICurrencyHandler
    {
        public double GetCurrencyFromRealTimeAPI()
        {
            double value=0;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://api.exchangeratesapi.io/");

                var result = client.GetAsync("latest").GetAwaiter().GetResult();

                if(result.IsSuccessStatusCode)
                {
                    var response = result.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    var modelResult = JsonConvert.DeserializeObject<Root>(response);

                    value = modelResult.rates.USD;
                }

            }
            return value;
        }

    }
}
