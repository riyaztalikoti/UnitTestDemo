﻿namespace UnitTestDemo.Currency
{
    public interface ICurrencyHandler
    {
        double GetCurrencyFromRealTimeAPI();
    }
}
