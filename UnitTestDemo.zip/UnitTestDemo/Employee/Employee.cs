﻿namespace UnitTestDemo
{
    public class Employee
    {
        public string Name { get; set; }

        public string City { get; set; }

        public int Age { get; set; }
    }
}
