﻿using System;
using UnitTestDemo.Currency;

namespace UnitTestDemo
{
    public class EmployeeHandler
    {

        public int GetEmployeeDiscount(Employee employee)
        {
            try
            {
                // Currency API call or It may DB? Mock

                if (employee.Age <= 0)
                {
                    throw new ArgumentException($"Input employee age is invalid{typeof(Employee)}");
                }

                // Business rules
                if (employee.Age > 35)
                {
                    return 25;
                }

                if (employee.Age > 50)
                {
                    return 30;
                }

                return 10;

            }
            catch (Exception)
            {

                throw;
            }
        }

        public double GetEmployeeSalaryInDoller(int basicSalary, ICurrencyHandler _currencyHandler)
        {
            var usdDoller = _currencyHandler.GetCurrencyFromRealTimeAPI(); // Dependency 

            return basicSalary * usdDoller;
        }
    }
}
