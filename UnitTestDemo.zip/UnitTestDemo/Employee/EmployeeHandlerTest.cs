﻿using Moq;
using NUnit.Framework;
using System;
using UnitTestDemo.Currency;

namespace UnitTestDemo
{
    [TestFixture]
    public class EmployeeHandlerTest
    {
        [Test]
        public void EmployeeHandler_GetEmployeeDiscount_Should_Return_Discount()
        {
            // Arrange
            var employee = new Employee()
            {
                Name = "Peter",
                Age = 38,
                City = "Bangalore"
            };
            var expectedDiscount = 25;

            // Act
            EmployeeHandler employeeHandler = new EmployeeHandler();
            var actualDiscount = employeeHandler.GetEmployeeDiscount(employee);

            // Assert
            Assert.IsNotNull(employee);
            Assert.AreSame(expectedDiscount, actualDiscount);
        }

        [Test]
        public void EmployeeHandler_GetEmployeeDiscount_Should_Return_Exception_When_Age_Is_Not_Set()
        {
            // Arrange
            Employee employee = new Employee()
            {
                Name = "John",
                City = "Pune"
            };

            // Act
            EmployeeHandler employeeHandler = new EmployeeHandler();

            Assert.Throws<ArgumentException>(() => employeeHandler.GetEmployeeDiscount(employee));
        }

        [Test]
        public void EmployeeHandler_GetEmployeeSalaryInDoller_Should_Return_Salary_Using_Mock_Doller()
        {
            // Arrange
            int salary = 10000;
            int expected = 15600;

            // Mock
            var mockedCurrencyInterface = new Mock<ICurrencyHandler>();
            mockedCurrencyInterface.Setup(x => x.GetCurrencyFromRealTimeAPI()).Returns(1.56); // mock value is 1.56

            // Act
            EmployeeHandler employeeHandler = new EmployeeHandler();
            var result= employeeHandler.GetEmployeeSalaryInDoller(salary, mockedCurrencyInterface.Object);

            // Assert
            Assert.AreEqual(expected, result);

        }
    }
}
