﻿using NUnit.Framework;

namespace UnitTestDemo
{
    [TestFixture]
    public class CalculatorTest
    {
        [Test]
        public void Calculate_Additon_Sum_Of_Two_Numbers_Should_Return()
        {
            // Arrange
            int number1 = 10;
            int number2 = 20;
            int expected = 30;

            // Act
            Calculator calculator = new Calculator();
            var actual = calculator.Addition(number1, number2);

            // Assert
            Assert.AreEqual(expected, actual);
        }


        [TestCase(10,20,30)]
        [TestCase(-10, -20, -30)]
        public void Calculate_Additon_Sum_Of_Two_Numbers_Should_Return(int number1,int number2,int expected)
        {
             // Act
            Calculator calculator = new Calculator();
            var actual = calculator.Addition(number1, number2);

            // Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
