﻿using System;
using UnitTestDemo.Currency;

namespace UnitTestDemo
{
    public class Program
    {
        static void Main(string[] args)
        {
            CurrencyHandler currencyHandler = new CurrencyHandler();

            double usdDoller = currencyHandler.GetCurrencyFromRealTimeAPI();

            Console.ReadKey();
        }
    }
}
